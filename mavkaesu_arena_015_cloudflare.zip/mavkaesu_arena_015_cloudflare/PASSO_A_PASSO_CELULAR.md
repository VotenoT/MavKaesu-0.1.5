# Passo a passo pelo celular

## 1. Crie uma conta no Cloudflare

Entre no site da Cloudflare pelo navegador do celular e crie uma conta grátis.

## 2. Crie um repositório no GitHub

Pelo navegador ou app do GitHub:

1. Crie um repositório novo.
2. Envie todos os arquivos deste ZIP.
3. A estrutura precisa ficar assim na raiz:

```txt
wrangler.toml
package.json
src/worker.js
public/index.html
```

Não deixe uma pasta extra por cima.

## 3. Conecte o GitHub no Cloudflare

No painel da Cloudflare:

1. Vá em Workers & Pages.
2. Clique em Create application.
3. Escolha Import a repository.
4. Conecte sua conta GitHub.
5. Escolha o repositório do MAVKaesu.

## 4. Configuração de deploy

Use:

```txt
Root directory: /
Build command: deixe vazio
Deploy command: npm run deploy
```

Se o Cloudflare reclamar do nome, troque o `name` no `wrangler.toml` para um nome único, por exemplo:

```toml
name = "mavkaesu-arena-015-kaio"
```

## 5. Publique

Clique em Save and Deploy.

Depois do deploy, abra o link `.workers.dev`.

## 6. Como testar

1. Abra o link em um celular.
2. Digite seu nome.
3. Escolha personagem.
4. Clique em Criar sala.
5. Copie o código.
6. Abra o mesmo link em outro celular/aba.
7. Digite o código e entre.

## 7. Diagnóstico

Teste:

```txt
https://seu-worker.workers.dev/health
```

Depois de criar sala:

```txt
https://seu-worker.workers.dev/room/CODIGO/status
```

## 8. Controles

- Segure o botão ATK/Q/W/ULT.
- Arraste para mirar.
- Solte para atacar.
- Toque rápido usa autoaim.
- Botão Imersivo tenta fullscreen.
- Botão Landscape gira visualmente o jogo mesmo em portrait.
