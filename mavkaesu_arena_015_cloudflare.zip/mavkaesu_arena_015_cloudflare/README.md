# MAVKaesu Arena 0.1.5 - Cloudflare Edition

Esta versão foi adaptada para **Cloudflare Workers + Durable Objects + WebSocket puro**.

## O que mudou

- Não usa Node.js tradicional.
- Não usa Socket.IO.
- Cada sala é um Durable Object.
- O HTML é servido como Static Assets do Worker.
- O multiplayer usa `new WebSocket(...)`.

## Arquivos principais

```txt
wrangler.toml
package.json
src/worker.js
public/index.html
```

## Comandos para PC/terminal

```bash
npm install
npm run dev
npm run deploy
```

## Endpoints

- `/` abre o jogo.
- `/health` testa se o Worker está vivo.
- `/ws/CODIGO` conecta o WebSocket da sala.
- `/room/CODIGO/status` mostra status básico da sala.

## Observações

- O plano grátis da Cloudflare tem limites.
- Esta build foi pensada para 1v1/2v2 pequeno.
- Não coloque centenas de minions/projéteis em Workers grátis.
- Não apague a migration `v1` depois de publicar.
