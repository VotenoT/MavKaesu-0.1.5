import fs from "node:fs";
const html = fs.readFileSync("public/index.html", "utf8");
if (!html.includes("new WebSocket")) throw new Error("Cliente não parece usar WebSocket.");
if (!html.includes("MAVKaesu Arena")) throw new Error("HTML inesperado.");
console.log("Cliente OK");
